# 🌱 Crop Prediction System (ML Project)

## Run Steps

### 1. Install dependencies
pip install -r requirements.txt

### 2. Train model (first time)
python train_model.py

### 3. Predict crop
python predict.py
